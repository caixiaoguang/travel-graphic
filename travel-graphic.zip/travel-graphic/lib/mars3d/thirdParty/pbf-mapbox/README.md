# Cesium对mvt的pbf的矢量瓦片图层的扩展插件
 

 基于mapbox-gl框架对pbf的解析，引接到cesium中来。 


https://github.com/kikitte/MVTImageryProvider
其中底层依赖 https://github.com/landtechnologies/Mapbox-vector-tiles-basic-js-renderer
