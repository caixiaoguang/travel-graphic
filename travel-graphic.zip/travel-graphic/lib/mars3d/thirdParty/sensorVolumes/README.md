# Cesium可视化 传感器体 的插件
 
  该插件会自动增加支持的CZML性质agi_conicSensor，agi_customPatternSensor和agi_rectangularSensor。
  相应的Entity属性是conicSensor，customPatternSensor，和rectangularSensor。

 源码：https://github.com/jlouns/cesium-sensor-volumes
